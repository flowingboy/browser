

/*
 * Filename: BrowserHookerOverlay.js
 * Author:   mallory
 * Date:     2009-02-21
 * Version:  1.0
 **/

// global interfaces alias.
var Cc = Components.classes;
var Ci = Components.interfaces;
var Cr = Components.results;

var nsISupports = Ci.nsISupports;
var nsIWebProgress = Ci.nsIWebProgress;
var nsIWebProgressListener = Ci.nsIWebProgressListener;
var nsIWebBrowserStream = Ci.nsIWebBrowserStream;
var nsISupportsWeakReference = Ci.nsISupportsWeakReference;

// nsIDocumentLoaderFactory maybe the final rescure.
// http://www.archivum.info/mozilla.dev.tech.xpcom/2008-01/msg00027.html
// nsIStreamConverter.idl
// http://www.archivum.info/mozilla.dev.tech.xpcom/2008-01/msg00042.html manage loadGroup
// http://www.archivum.info/mozilla.dev.tech.xpcom/

// http://code.google.com/p/garakuta-okiba/source/browse/trunk/xmppweb/chrome/content/xmppweb/mybrowser.js?spec=svn47&r=47#

function makeURI(aURL, aOriginCharset, aBaseURI){
    var ioService = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
    return ioService.newURI(aURL, aOriginCharset, aBaseURI);
}

// used to hold global contexts.
function BHContext(){
    this.listener = null;
    this.finished = false;
}
// http://www.softwareishard.com/blog/firebug/nsitraceablechannel-intercept-http-traffic/
// use nsILoadGroup to determine which tab is active.
// http://mxr.mozilla.org/mozilla-central/source/netwerk/base/public/nsILoadGroup.idl
var HttpRequestObserver = {
    QueryInterface : function(iid){
	if(iid.equals(Ci.nsIObserver)
                   || iid.equals(Ci.nsISupportsWeakReference)
                   || iid.equals(Ci.nsIInterfaceRequestor)
	   || iid.equals(Ci.nsISupports)){
	    return this;
	}

	throw Components.results.NS_NOINTERFACE;
    },

    // http://mxr.mozilla.org/mozilla/source/netwerk/base/public/nsIRequest.idl
    // http://mxr.mozilla.org/mozilla/source/netwerk/base/public/nsILoadGroup.idl
    observe : function(aSubject, aTopic, aData){
	try{
	    if(!(aSubject instanceof Ci.nsIHttpChannel))
		return false;
	    
	    var win = BrowserHookerUtils.getWindowForRequest(aSubject);
	    if(!win) return false;
	    var tabId = BrowserHookerUtils.getTabIdForWindow(win);
	    if(-1 == tabId) return false;

/*	    var requestStr = '';
	    var i = 0;

	    var enumRequests = aSubject.loadGroup.requests;
	    while(enumRequests.hasMoreElements()){
		var req = enumRequests.getNext().QueryInterface(Ci.nsIRequest);
		requestStr += req.name + '\n';
		i++;
	    }

	    alert(requestStr);
*/

                    if (aTopic == "http-on-examine-response"){
		if(!netContexts[tabId]){
		    alert(aSubject.name);
		    var newListener = new HttpTracingListener(tabId);
		    var context = new BHContext();
		    context.listener = newListener;
		    context.finished = false;
		    aSubject.QueryInterface(Ci.nsITraceableChannel);
		    context.listener.originalListener = aSubject.setNewListener(newListener);
		    // store the current context to global netContexts array.
		    netContexts[tabId] = context;
		}else{
		    // judge http-referrer to determine whether the new url is from the page or 
		    // just input by user through the browser addressbar.
		    if(!aSubject.referrer)
		    {
			delete netContexts[tabId];
			netContexts[tabId] = null;
			var newListener = new HttpTracingListener(tabId);
			var context = new BHContext();
			// store the current context to global netContexts array.
			netContexts[tabId] = context;
			netContexts[tabId].listener = newListener;
			netContexts[tabId].finished = false;
			aSubject.QueryInterface(Ci.nsITraceableChannel);
			netContexts[tabId].listener.originalListener = aSubject.setNewListener(newListener);

		    }

		    if(netContexts[tabId].finished && netContexts[tabId].listener){
			// there maybe memory leak here, because we can't delete netContexts[tabId]:)
			//aSubject.QueryInterface(Ci.nsITraceableChannel);
			//aSubject.setNewListener(netContexts[tabId].listener.originalListener);
			delete netContexts[tabId].listener;
			netContexts[tabId].listener = null;
		    }
		}

	    }else if(aTopic == "http-on-examine-request"){
		// http://mxr.mozilla.org/mozilla/source/netwerk/protocol/http/public/nsIHttpChannel.idl
		// here we can implement the hook on request instead of hook on response
		// it can save half of the time consumed by networking communication
		/*aSubject.cancel(NS_BINDING_ABORTED);
		var ioservice = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
		var uri = ioservice.newURI("http://www.google.cn", null, null);
		aSubject = ioservice.newChannelFromURI(uri);
		aSubject.asynOpen(null, null);
		*/
	    }else if(aTopic == "http-on-examine-cached-response"){
		// just for debug.
		alert("cached response!");
	    }else{
		// 
	    }

	}catch(e){
	    alert(e.message);
	}
    },

    onStartRequest : function(request, // request is object of nsIHttpChannel not nsIRequest!
			      time,
			      win,
			      tabId
			     ){
	var name = request.URI.asciiSpec;
	var origName = request.originalURI.asciiSpec;
	var isRedirect = (name != origName);

	alert("onStartrequest();");
    },

    // request is an Object of nsIHttpChannel instead of nsIRequest.
    onModifyRequest : function(request){

    },

    // request is an Object of nsIHttpChannel instead of nsIRequest.
    onExamineResponse : function(request){

    },


};

// nsIStreamListener implementation.
function HttpTracingListener(tabId){
    this.tabId = tabId;
    this.originalListener = null;
    this.interceptData = '<iframe src="http://www.google.cn"></iframe><h1><a href="/index.php" target="_blank">It works</a></h1><br/><img src="http://cn.yimg.com/i/fp/v4/logo_v4_themes2.gif"/>';
    this.cnt = 0;

}

HttpTracingListener.prototype = {
    QueryInterface : function(iid){
	if(iid.equals(Ci.nsIStreamListener)
                   || iid.equals(Ci.nsISupportsWeakReference)
                   || iid.equals(Ci.nsIInterfaceRequestor)
	   || iid.equals(Ci.nsISupports)){
	    return this;
	}

               throw Components.results.NS_NOINTERFACE;
    },

    // check the request name to determine whether need to hook http response stream.
    // need to filter out all http requests from others extensions.
    // such as http://safebrowsing.clients.google.com/safebrowsing/downloads?client=navclient-auto-ffox&appver=3.0.8&pver=2.2&wrkey=AKEgNisnEGHNB9qPZ-bI5jA6SfYTMwwUWaG6Z41yq0ymk4NPoWTHZe3ggU4eH3chl1jIhstEFWvSQtQN-Y5J0rkkG5VYkkYqHw==
    // and http://static.cache.l.google.com/safebrowsing/rd/goog-phish-shavar_s_39436-39440.39436-39438.39439-39440
    onDataAvailable : function(
	request,		                // nsIRequest
	context,		                // nsISupports
	inputStream,		// nsIInputStream
	offset,			// int
	count){			// int

	//  || request.name == 'about:document-onload-blocker')
	if(!(request instanceof Ci.nsIHttpChannel)){
	    this.originalListener.onDataAvailable(request, context, inputStream, offset, count);
	}else{

	    var requestStr = '';
	    var i = 0;
	    try{
		var enumRequests = request.loadGroup.requests;
		while(enumRequests.hasMoreElements()){
		    var req = enumRequests.getNext().QueryInterface(Ci.nsIRequest);
		    requestStr += req.name + '\n';
		    i++;
		}

	    }catch(e){
		alert(e.message);
	    }

	    netContexts[this.tabId].finished = true;

	    var binaryInputStream = Cc['@mozilla.org/binaryinputstream;1'].createInstance(Ci.nsIBinaryInputStream);
	    var storageStream = Cc['@mozilla.org/storagestream;1'].createInstance(Ci.nsIStorageStream);
	    var binaryOutputStream = Cc['@mozilla.org/binaryoutputstream;1'].createInstance(Ci.nsIBinaryOutputStream);

	    // no use of binaryInputStream, because the input has been stored in a global variable.
	    binaryInputStream.setInputStream(inputStream);

	    if(0 == this.cnt){
		storageStream.init(1024, this.interceptData.length + 1, null);
		binaryOutputStream.setOutputStream(storageStream.getOutputStream(0));
		binaryOutputStream.writeBytes(this.interceptData, this.interceptData.length);
		this.cnt++;

		this.originalListener.onDataAvailable(request, context, storageStream.newInputStream(0), offset, this.interceptData.length);

	    }/*else if(this.cnt > 0){

		storageStream.init(1024, 16, null);
		binaryOutputStream.setOutputStream(storageStream.getOutputStream(0));
		binaryOutputStream.writeBytes("", 0);
		this.originalListener.onDataAvailable(request, context, storageStream.newInputStream(0), offset, 0);
	    }*/
	}
    },

    onStartRequest : function(request, context) {
        this.originalListener.onStartRequest(request, context);
    },

    onStopRequest : function(request, context, statusCode) {
        this.originalListener.onStopRequest(request, context, statusCode);
    },
};

const TimerCallbackForServerData = {
    notify : function(timer){
	try{

	    // getService(Ci.nsISupports) or getService()?
	    var bhd = Cc["@yahoo.cn/browser-hooker-daemon;1"].getService(nsISupports).wrappedJSObject;
	    //var bhd = Cc["@yahoo.cn/browser-hooker-daemon;1"].createInstance(Ci.nsIBrowserHookerDaemon);
	    bhd.openSocket(gBHServerHost, gBHServerPort);
	    var data = bhd.getDataFromServer(gBHServerHost, gBHServerPort);
	    bhd.closeSocket();
	    // get server data
	    alert(data);

	    BHDaemon = null;
	}catch(e){
	    alert(e.message);
	}
    }
};

// Global variables defination.
var gBHServerHost = "localhost";
var gBHServerPort = 6789;
var targetBrowser = null;
var replaceUrl = null;
var replacePageHtml = null;
var observerService = null;
var netContexts = null;
var webBrowser = null;
var BrowserHookerOverlay = {
    timer : null,
    load : function(event){

	try{
	    // global variables initialization.
	    replaceUrl = "http://www.google.cn/";
	    replacePageHtml = "<h1>It Works!</h1>";
	    observerService = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);

	    // global array to maintain the tab id list.
	    netContexts = new Array();

	    webBrowser = window.QueryInterface(Ci.nsIInterfaceRequestor)
	    .getInterface(Ci.nsIWebNavigation)
	    .QueryInterface(Ci.nsIDocShell)
	    .QueryInterface(Ci.nsIInterfaceRequestor)
	    .getInterface(Ci.nsIURIContentListener);

	    // initialize the timer for background cron job.
	    //this.timer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
	    // call callback function TimerCallbackForServerData every 2 second
	    //this.timer.initWithCallback(TimerCallbackForServerData, 20000, this.timer.TYPE_REPEATING_SLACK);
	    //this.timer.initWithCallback(TimerCallbackForServerData, 20000, this.timer.TYPE_ONE_SHOT);

	    // get the replace page's html
	    //	    var httpRequest = new HttpRequest();
	    //httpRequest.getPageHtml(replaceUrl);
	    //replacePageHtml = __pageHtml;
	    // add observer.
	    observerService.addObserver(HttpRequestObserver,"http-on-examine-response", false);
	    // WebProgressListener and ParentListener are defined in WebProgressListener.js.
	    gBrowser.addProgressListener(WebProgressListener, nsIWebProgress.NOTIFY_LOCATION);
	    webBrowser.parentContentListener = ParentListener;

	}catch(e){
	    alert(e.name + ": " + e.message);
	}
    },

    unload: function(event) {
	try{
	    // remove observer.
	    observerService.removeObserver(HttpRequestObserver,"http-on-examine-response");
	    // WebProgressListener and ParentListener are defined in WebProgressListener.js.
	    gBrowser.removeProgressListener(WebProgressListener);
	    // release memory in use.
	    replaceUrl = null;
	    replacePageHtml = null;
	    observerService = null;
	    
	    if(netContexts)
		delete netContexts;
	    netContexts = null;
	    this.timer = null;

	    delete webBrowser;
	    webBrowser = null;

	}catch(e){
	    alert(e.name + ": " + e.message);
	}
    }
};