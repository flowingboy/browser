var Cc = Components.classes;
var Ci = Components.interfaces;
var Cr = Components.results;

// here as the ip address maybe changed frequently, so I use dns name instead.
var gBHServerHost = "localhost";
var gBHServerPort = 6789;

//0xadd35f3f, 0x9f63, 0x42c5, 0xb7, 0x60, 0xe1, 0xf1, 0xa1, 0x59, 0xf0, 0x0);
// register BrowserHookerDaemon service.
BrowserHookerDaemon.classID = Components.ID("{ADD35F3F-9F63-42c5-B760-E1F1A159F000}");
BrowserHookerDaemon.contractID = "@yahoo.cn/browser-hooker-daemon;1";
BrowserHookerDaemon.classDescription = "BrowserHooker communication daemon";

// component defination.
function BrowserHookerDaemon(){
    this.ServHost = null;
    this.ServPort = null;
    this.interval = null;
    this.socketTransport = null;
    this.DaemonSocket = null;
    this.input = null;
    // initialize the timer for background cron job.
    this.timer = Cc["@mozilla.org/timer;1"].createInstance(CI.nsITimer);

    // used to hold data from server.
    this.data = null;

    // for javascript call this component.
    this.wrappedJSObject = this;
}

// https://developer.mozilla.org/en/nsISocketTransportService
// https://developer.mozilla.org/en/nsITransport
// https://developer.mozilla.org/En/nsISocketTransport
// http://www.cnblogs.com/phinecos/archive/2008/05/20/1203635.html

// should call setEventSink function to specify which thread will listening on the socket.
// http://mxr.mozilla.org/mozilla/source/netwerk/base/public/nsITransport.idl
BrowserHookerDaemon.prototype = {
    QueryInterface : function(){
	if(!iid.equals(nsISupports)){
	    throw NS_ERROR_NO_INTERFACE;
	}
	return this;
    },

    openSocket : function(host, port){
	this.ServHost = host;
	this.ServPort = port;

	if(!this.DaemonSocket){
	    try{
		// initialize the socket to connect to the monitor server.
		var socketTransportService = Cc["@mozilla.org/network/socket-transport-service;1"].getService(Ci.nsISocketTransportService);
		this.DaemonSocket = socketTransportService.createTransport(null, 3, this.ServHost, this.ServPort, null); // first parameter
	    }catch(e){
		alert(e.message);
	    }
	}

	// use un-blocking and un-buffering stream.
	var istream = this.DaemonSocket.openInputStream(0, 0);
	if(!istream){
	    this.closeSocket();
	    return;
	}

	this.input = Cc["@mozilla.org/scriptableinputstream;1"].createInstance(Ci.nsIScriptableInputStream);
	if(!this.input){
	    this.closeSocket();
	    return;
	}

	this.input.init(istream);
    },

    // get data from server
    getDataFromServer : function(){
	if(!this.input){
	    this.openSocket(gBHServerHost, gBHServerPort);
	}

	try{
	    // WARNING: If the data contains a null byte, then this method will return a truncated string.
	    var result = this.input.read(256);
	    if(result.length > 0){
		alert(result);
	    }
	}catch(e){
	    alert(e.message);
	}
    },

    closeSocket : function(){
	if(this.input){
	    this.input.close(null);
	    this.input = null;
	}

	if(this.DaemonSocket){
	    this.DaemonSocket.close(null);
	    this.DaemonSocket = null;
	}
    },

    getUrlMap : function(){

    }
};

/* class factory.
 * This object is a member of the global-scope Components.classes.
 * It is keyed off of the contract ID. Eg:
 * var myBHDaemon = Cc['@yahoo.cn/browser-hooker-daemon;1'].createInstance(Ci.nsIBrowserHookerDaemon);
**/
var BrowserHookerDaemonFactory = {
    createInstance : function(outer, iid){
	if(outer != null)
	    throw Cr.NS_ERROR_NO_AGGREGATION;
	
	return (new BrowserHookerDaemon()).QueryInterface(iid);
    }
};

// module defination(xpcom registration)
var BrowserHookerDaemonModule = {
    registerSelf : function(compMgr, fileSpec, location, type){
	compMgr = compMgr.QueryInterface(nsIComponentRegistrar);
	compMgr.registerFactoryLocation(CLASS_ID, CLASS_NAME, CONTRACT_ID, fileSpec, location, type);
    },

    unregisterSelf : function(compMgr, location, type){
	compMgr = compMgr.QueryInterface(nsIComponentRegistrar);
	compMgr.unregisterFactoryLocation(CLASS_ID, location);
    },

    getClassObject : function(compMgr, CID, IID){
        if (!iid.equals(nsIFactory))
            throw NS_ERROR_NOT_IMPLEMENTED;

        if (cid.equals(CLASS_ID))
            return FirebugFactory;

        throw NS_ERROR_NO_INTERFACE;
    },

    canUnload : function(compMgr){
	return true;
    }
};

function NSGetModule(compMgr, fileSpec){
    return BrowserHookerDaemonModule;
}

const TimerCallbackForServerData = {
    notify : function(timer){
	try{
	    // getService(Ci.nsISupports) or getService()?
	    var BHDaemon = Cc['@yahoo.cn/BrowserHooker/daemon;1'].getService().wrappedJSObject;
	    BHDaemon.openSocket(gBHServerHost, gBHServerPort);
	    BHDaemon.getDataFromServer();
	    BHDaemon.closeSocket();
	    // get server data
	    
	    BHDaemon = null;
	}
    }
};