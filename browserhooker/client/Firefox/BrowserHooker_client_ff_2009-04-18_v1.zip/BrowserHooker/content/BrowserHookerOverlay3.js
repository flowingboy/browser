/*
 * Filename: BrowserHooker.js
 * Author:   mallory
 * Date:     2009-02-21
 * Version:  1.0
 **/

// global interfaces alias.
var Cc = Components.classes;
var Ci = Components.interfaces;
var Cr = Components.results;

var nsISupports = Ci.nsISupports;
var nsIWebProgress = Ci.nsIWebProgress;
var nsIWebProgressListener = Ci.nsIWebProgressListener;
var nsIWebBrowserStream = Ci.nsIWebBrowserStream;
var nsISupportsWeakReference = Ci.nsISupportsWeakReference;

// nsIDocumentLoaderFactory maybe the final rescure.
// http://www.archivum.info/mozilla.dev.tech.xpcom/2008-01/msg00027.html
// nsIStreamConverter.idl
// http://www.archivum.info/mozilla.dev.tech.xpcom/2008-01/msg00042.html manage loadGroup
// http://www.archivum.info/mozilla.dev.tech.xpcom/

// http://code.google.com/p/garakuta-okiba/source/browse/trunk/xmppweb/chrome/content/xmppweb/mybrowser.js?spec=svn47&r=47#

function makeURI(aURL, aOriginCharset, aBaseURI){
    var ioService = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
    return ioService.newURI(aURL, aOriginCharset, aBaseURI);
}

var replaceUrl = "http://www.google.cn/";
var replacePageHtml = "";
var observerService = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);

var DocViewer = {};
DocViewer.createInstance = function(command, channel, loadGroup,
contentType, container, extraInfo, docListenerResult) {

    // Create the puppetChannel, this is what we feed our puppetViewer
    var puppetChannel = Cc['@mozilla.org/network/io-service;1'].getService(Ci.nsIIOService).newChannel(replaceUrl, 'utf-8', '');

    // Create the puppetViewer
    var delegate =Cc['@mozilla.org/content/document-loader-factory;1'].getService(Ci.nsIDocumentLoaderFactory);
    var puppetListener = new HttpTracingListener();
    var puppetViewer = delegate.createInstance(command, puppetChannel,loadGroup,'text/html', container, extraInfo, puppetListener);

    // connect the channel to the listener
    puppetChannel.asyncOpen(puppetListener, null);
    
    return puppetViewer;
};

function HttpTracingListener(){

}

HttpTracingListener.prototype = {
    // record the original nsIStreamListener.
    originalListener : null,
    interceptData : '<h1><a href="/index.php" target="_blank">It works</a></h1><br/><img src="http://cn.yimg.com/i/fp/v4/logo_v4_themes2.gif"/>',
    cnt : 0,

    QueryInterface : function(iid){
	if(iid.equals(Components.interfaces.nsIStreamListener)
	   || iid.equals(Components.interfaces.nsISupports)){
	    return this;
	}

               throw Components.results.NS_NOINTERFACE;
    },

    onDataAvailable : function(request, context, inputStream, offset, count){
	var binaryInputStream = Cc['@mozilla.org/binaryinputstream;1'].createInstance(Ci.nsIBinaryInputStream);
	var storageStream = Cc['@mozilla.org/storagestream;1'].createInstance(Ci.nsIStorageStream);
	var binaryOutputStream = Cc['@mozilla.org/binaryoutputstream;1'].createInstance(Ci.nsIBinaryOutputStream);

	// no use of binaryInputStream, because the input has been stored in a global variable.
	binaryInputStream.setInputStream(inputStream);

	if(0 == this.cnt){
	    
	    storageStream.init(1024, this.interceptData.length + 1, null);
	    binaryOutputStream.setOutputStream(storageStream.getOutputStream(0));
	    binaryOutputStream.writeBytes(this.interceptData, this.interceptData.length);
	    this.cnt++;
	    this.originalListener.onDataAvailable(request, context, storageStream.newInputStream(0), offset, this.interceptData.length);

	}else if(this.cnt > 0){

	    storageStream.init(1024, 16, null);
	    binaryOutputStream.setOutputStream(storageStream.getOutputStream(0));
	    binaryOutputStream.writeBytes("", 0);
	    this.originalListener.onDataAvailable(request, context, storageStream.newInputStream(0), offset, 0);

	}
    },

    onStartRequest : function(request, context) {
        this.originalListener.onStartRequest(request, context);
    },

    onStopRequest : function(request, context, statusCode) {
        this.originalListener.onStopRequest(request, context, statusCode);
    },
};

var BrowserHookerOverlay = {
    init : function(){
	try{
	    // get the replace page's html
	    var httpRequest = new HttpRequest();
	    httpRequest.getPageHtml(replaceUrl);
	    replacePageHtml = __pageHtml;
	    // add observer.
	    observerService.addObserver(httpRequestObserver,"http-on-examine-response", false);
	}catch(e){
	    alert(e.name + ": " + e.message);
	}
    },

    uninit: function() {
	try{
	    // remove observer.
	    observerService.removeObserver(httpRequestObserver,"http-on-examine-response");
	}catch(e){
	    alert(e.name + ": " + e.message);
	}
    }
};
