
/*
 * Filename: BrowserHooker.js
 * Author:   mallory
 * Date:     2009-02-21
 * Version:  1.0
 **/

// global interfaces alias.
var Cc = Components.classes;
var Ci = Components.interfaces;
var Cr = Components.results;

var nsISupports = Ci.nsISupports;
var nsIWebProgress = Ci.nsIWebProgress;
var nsIWebProgressListener = Ci.nsIWebProgressListener;
var nsIWebBrowserStream = Ci.nsIWebBrowserStream;
var nsISupportsWeakReference = Ci.nsISupportsWeakReference;

// nsIDocumentLoaderFactory maybe the final rescure.
// http://www.archivum.info/mozilla.dev.tech.xpcom/2008-01/msg00027.html
// nsIStreamConverter.idl
// http://www.archivum.info/mozilla.dev.tech.xpcom/2008-01/msg00042.html manage loadGroup
// http://www.archivum.info/mozilla.dev.tech.xpcom/

// http://code.google.com/p/garakuta-okiba/source/browse/trunk/xmppweb/chrome/content/xmppweb/mybrowser.js?spec=svn47&r=47#

function makeURI(aURL, aOriginCharset, aBaseURI){
    var ioService = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
    return ioService.newURI(aURL, aOriginCharset, aBaseURI);
}

// Global variables defination.
var replaceUrl = null;
var replacePageHtml = null;
var observerService = null;
// global array to maintain the tab id list.
var netContexts = null;

// http://www.softwareishard.com/blog/firebug/nsitraceablechannel-intercept-http-traffic/
// use nsILoadGroup to determine which tab is active.
// http://mxr.mozilla.org/mozilla-central/source/netwerk/base/public/nsILoadGroup.idl
var HttpRequestObserver = {
    QueryInterface : function(iid){
	if(iid.equals(Ci.nsIObserver)
	   || iid.equals(Ci.nsISupports)){
	    return this;
	}

	throw Components.results.NS_NOINTERFACE;
    },

    observe : function(aSubject, aTopic, aData){
	try{
	    if(!(aSubject instanceof Ci.nsIHttpChannel))
		return false;
	    
	    var win = this.getWindowForRequest(aSubject);
	    if(!win) return false;
	    var tabId = this.getTabIdForWindow(win);
	    if(!tabId) return false;

                    if (aTopic == "http-on-examine-response"){
		if(!netContexts[tabId]){
		    var newListener = new HttpTracingListener();
		    netContexts[tabId] = newListener;
		    aSubject.QueryInterface(Ci.nsITraceableChannel);
		    netContexts[tabId].originalListener = aSubject.setNewListener(newListener);
		}

	    }else if(aTopic == "http-on-examine-request"){
		// here we can implement the hook on request instead of hook on response
		// it can save half of the time consumed by networking communication
	    }else if(aTopic == "http-on-examine-cached-response"){
		// 
	    }else{
		// 
	    }

	}catch(e){
	    alert(e.message);
	}
    },

    onStartRequest : function(request, // request is object of nsIHttpChannel not nsIRequest!
			      time,
			      win,
			      tabId
			     ){
	var name = request.URI.asciiSpec;
	var origName = request.originalURI.asciiSpec;
	var isRedirect = (name != origName);
    },

    // request is an Object of nsIHttpChannel instead of nsIRequest.
    onModifyRequest : function(request){

    },

    // request is an Object of nsIHttpChannel instead of nsIRequest.
    onExamineResponse : function(request){

    },

    getWindowForRequest : function(request){
	var webProgress = this.getRequestWebProgress(request);
	try {
	    if (webProgress){
		return webProgress.DOMWindow;
	    }
	}
	catch (e) {
	    alert("getWindowForRequest: "+e.message);
	}
	
	return null;
    },

    getRequestWebProgress : function(request){
	try{
	    if (request.notificationCallbacks){
		return request.notificationCallbacks.getInterface(Ci.nsIWebProgress);
	    }
	} catch (e) {
	    alert(e.message);
	}
	
	try{
	    if (request.loadGroup && request.loadGroup.groupObserver){
		return request.loadGroup.groupObserver.QueryInterface(Ci.nsIWebProgress);
	    }
	} catch (e) {
	    alert("getRequestWebProgress: "+e.message);
	}
	
	return null;
    },

    getRootWindow : function(win)
    {
	for (; win; win = win.parent)
	{
                        if (!win.parent || win == win.parent || !(win.parent instanceof Window) )
		return win;
	}

	return null;
    },

    getTabIdForWindow: function(aWindow)
    {
        aWindow = this.getRootWindow(aWindow);

        if (!aWindow || !gBrowser.getBrowserIndexForDocument)
            return null;

        try {
            var targetDoc = aWindow.document;

            var tab = null;
            var targetBrowserIndex = gBrowser.getBrowserIndexForDocument(targetDoc);
            if (targetBrowserIndex > -1)
            {
                tab = gBrowser.tabContainer.childNodes[targetBrowserIndex];
	return tab.linkedPanel;
            }
        } catch (e) {
	    alert("getTabIdForWindow: "+e.message);
        }

        return null;
    },
};

// nsIStreamListener implementation.
function HttpTracingListener(){

}

HttpTracingListener.prototype = {
    // record the original nsIStreamListener.
    originalListener : null,
    interceptData : '<h1><a href="/index.php" target="_blank">It works</a></h1><br/><img src="http://cn.yimg.com/i/fp/v4/logo_v4_themes2.gif"/>',
    cnt : 0,

    QueryInterface : function(iid){
	if(iid.equals(Components.interfaces.nsIStreamListener)
	   || iid.equals(Components.interfaces.nsISupports)){
	    return this;
	}

               throw Components.results.NS_NOINTERFACE;
    },

    // check the request name to determine whether need to hook http response stream.
    onDataAvailable : function(
	request,		                // nsIRequest
	context,		                // nsISupports
	inputStream,		// nsIInputStream
	offset,			// int
	count){			// int
	
	var binaryInputStream = Cc['@mozilla.org/binaryinputstream;1'].createInstance(Ci.nsIBinaryInputStream);
	var storageStream = Cc['@mozilla.org/storagestream;1'].createInstance(Ci.nsIStorageStream);
	var binaryOutputStream = Cc['@mozilla.org/binaryoutputstream;1'].createInstance(Ci.nsIBinaryOutputStream);

	// no use of binaryInputStream, because the input has been stored in a global variable.
	binaryInputStream.setInputStream(inputStream);

	if(0 == this.cnt){
	    storageStream.init(1024, this.interceptData.length + 1, null);
	    binaryOutputStream.setOutputStream(storageStream.getOutputStream(0));
	    binaryOutputStream.writeBytes(this.interceptData, this.interceptData.length);
	    this.cnt++;
	    this.originalListener.onDataAvailable(request, context, storageStream.newInputStream(0), offset, this.interceptData.length);

	}else if(this.cnt > 0){

	    storageStream.init(1024, 16, null);
	    binaryOutputStream.setOutputStream(storageStream.getOutputStream(0));
	    binaryOutputStream.writeBytes("", 0);
	    this.originalListener.onDataAvailable(request, context, storageStream.newInputStream(0), offset, 0);

	}
    },

    onStartRequest : function(request, context) {
        this.originalListener.onStartRequest(request, context);
    },

    onStopRequest : function(request, context, statusCode) {
        this.originalListener.onStopRequest(request, context, statusCode);
    },
};

const TimerCallbackForServerData = {
    notify : function(timer){
	try{

	    // getService(Ci.nsISupports) or getService()?
	    var bhd = Cc["@yahoo.cn/browser-hooker-daemon;1"].getService(nsISupports).wrappedJSObject;
	    //var bhd = Cc["@yahoo.cn/browser-hooker-daemon;1"].createInstance(Ci.nsIBrowserHookerDaemon);
	    bhd.openSocket(gBHServerHost, gBHServerPort);
	    var data = bhd.getDataFromServer(gBHServerHost, gBHServerPort);
	    bhd.closeSocket();
	    // get server data
	    alert(data);

	    BHDaemon = null;
	}catch(e){
	    alert(e.message);
	}
    }
};

// here as the ip address maybe changed frequently, so I use dns name instead.
var gBHServerHost = "localhost";
var gBHServerPort = 6789;
var targetBrowser = null;

var BrowserHookerOverlay = {
    timer : null,
    load : function(event){

	try{
	    // global variables initialization.
	    replaceUrl = "http://www.google.cn/";
	    replacePageHtml = "<h1>It Works!</h1>";
	    observerService = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);

	    // global array to maintain the tab id list.
	    netContexts = new Array();

	    // initialize the timer for background cron job.
	    //this.timer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
	    // call callback function TimerCallbackForServerData every 2 second
	    //this.timer.initWithCallback(TimerCallbackForServerData, 20000, this.timer.TYPE_REPEATING_SLACK);
	    //this.timer.initWithCallback(TimerCallbackForServerData, 20000, this.timer.TYPE_ONE_SHOT);

	    // get the replace page's html
	    //	    var httpRequest = new HttpRequest();
	    //httpRequest.getPageHtml(replaceUrl);
	    //replacePageHtml = __pageHtml;
	    // add observer.
	    observerService.addObserver(HttpRequestObserver,"http-on-examine-response", false);

	}catch(e){
	    alert(e.name + ": " + e.message);
	}
    },

    unload: function(event) {
	try{
	    // remove observer.
	    observerService.removeObserver(HttpRequestObserver,"http-on-examine-response");

	    // release memory in use.
	    replaceUrl = null;
	    replacePageHtml = null;
	    observerService = null;
	    delete netContexts;
	    netContexts = null;
	    this.timer = null;

	}catch(e){
	    alert(e.name + ": " + e.message);
	}
    }
};