/* 
 * Manage the http request.
 * Reference the mozilla official page: https://developer.mozilla.org/En/Creating_Sandboxed_HTTP_Connections
 *
**/

var __httpRequestChannel = null;
__pageHtml = '';
// HttpRequest class defination.
function HttpRequest(){}

HttpRequest.prototype = {
    url : '',

    getPageHtml : function(url){
	this.url = url;
	var ioservice = Components.classes["@mozilla.org/network/io-service;1"].getService(Components.interfaces.nsIIOService);
	var uri = ioservice.newURI(this.url, null, null);
	__httpRequestChannel = ioservice.newChannelFromURI(uri);

	var listener = new StreamListener( function(data){ __pageHtml = data; } );

	__httpRequestChannel.notificationCallbacks = listener;
	__httpRequestChannel.asyncOpen(listener, null);
    },
};

// StreamListener class defination.
function StreamListener(aCallbackFunc){
    this.mCallbackFunc = aCallbackFunc;
}

StreamListener.prototype = {
    mData : "",
    
    // start request event handler.
    onStartRequest : function (aRequest, aContext){
	this.mData = "";
    },

    onDataAvailable : function (aRequest, aContext, aStream, aSourceOffset, aLength){
	var scriptableInputStream = Components.classes["@mozilla.org/scriptableinputstream;1"]
        .createInstance(Components.interfaces.nsIScriptableInputStream);
	scriptableInputStream.init(aStream);

	this.mData += scriptableInputStream.read(aLength);
    },
    
    onStopRequest : function (aRequest, aContext, aStatus){
	if (Components.isSuccessCode(aStatus)) {
	    // request was successfull
	    this.mCallbackFunc(this.mData);
	} else {
	    // request failed
	    this.mCallbackFunc(null);
	}
	__httpRequestChannel = null;
    },

    onChannelRedirect: function (aOldChannel, aNewChannel, aFlags) {
	// if redirecting, store the new channel
	__httpRequestChannel = aNewChannel;
    },

    getInterface: function (aIID) {
	try {
	    return this.QueryInterface(aIID);
	} catch (e) {
	    throw Components.results.NS_NOINTERFACE;
	}
    },

    onProgress : function (aRequest, aContext, aProgress, aProgressMax) { },
    onStatus : function (aRequest, aContext, aStatus, aStatusArg) { },
    onRedirect : function (aOldChannel, aNewChannel) { },

    QueryInterface : function(aIID) {
	if (aIID.equals(Components.interfaces.nsISupports) ||
            aIID.equals(Components.interfaces.nsIInterfaceRequestor) ||
            aIID.equals(Components.interfaces.nsIChannelEventSink) ||
            aIID.equals(Components.interfaces.nsIProgressEventSink) ||
            aIID.equals(Components.interfaces.nsIHttpEventSink) ||
            aIID.equals(Components.interfaces.nsIStreamListener))
	    return this;

	throw Components.results.NS_NOINTERFACE;
    }

};