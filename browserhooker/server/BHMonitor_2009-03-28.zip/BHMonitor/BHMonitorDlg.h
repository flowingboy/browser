// BHMonitorDlg.h : header file
//

#if !defined(AFX_BHMONITORDLG_H__C32D2A4E_BE15_4EDE_A59C_98E7371CF8C7__INCLUDED_)
#define AFX_BHMONITORDLG_H__C32D2A4E_BE15_4EDE_A59C_98E7371CF8C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyIOCP.h"
#include "SettingDlg.h"
#include "MyListCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CBHMonitorDlg dialog

class CBHMonitorDlg : public CDialog
{
// Construction
public:
	CBHMonitorDlg(CWnd* pParent = NULL);	// standard constructor

	BOOL StartServer();

	void EnableAllPanels();
	void DisableAllPanels();
	void UpdateClientData();

// Dialog Data
	//{{AFX_DATA(CBHMonitorDlg)
	enum { IDD = IDD_BHMONITOR_DIALOG };
	CString	    m_WebsiteUrl;
	MyListCtrl  m_CtrlClientList;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBHMonitorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON            m_hIcon;
	MyIOCP           m_myIocp;
	CSettingDlg      m_ConfigDlg;
	int              m_iCurrentClientID;
	CCriticalSection m_GUIListLock;

	CString          m_sReceivedText;
	CString          m_sSendText;
	// Generated message map functions
	//{{AFX_MSG(CBHMonitorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtSave();
	afx_msg void OnRclickListUrl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkListUrl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnBtStartServer();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnCancelMode();
	afx_msg void OnBtSetting();
	virtual void OnOK();
	afx_msg void OnClose();
	afx_msg void OnChangeWebsiteUrl();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	LRESULT OnClientDisconnected(WPARAM wParam, LPARAM lParam);
	LRESULT OnNewClient(WPARAM wParam, LPARAM lParam);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BHMONITORDLG_H__C32D2A4E_BE15_4EDE_A59C_98E7371CF8C7__INCLUDED_)
